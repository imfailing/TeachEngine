﻿<?php
  $error = $_FILES['file']['error'];
  switch($error) {
    case 0 :
      $error = 'нет';
      break;    
    case 1 : case 2 :
      $error = 'cлишком большой файл';
      break;
    case 3 :
      $error = 'файл загружен частично';
      break;
    case 4 :
      $error = 'файл не был загружен';
  }
?>

Ваше имя: <?=$_POST['name']; ?><br />
Имя файла: <?=$_FILES['file']['name']; ?><br />
Mime type: <?=$_FILES['file']['type']; ?><br />
Ошибки: <?=$error; ?><br />
Размер файла: <?=$_FILES['file']['size']; ?> байт

