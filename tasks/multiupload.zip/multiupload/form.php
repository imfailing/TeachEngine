<?php
header('Content-Type: text/html; charset=utf-8');
$numoffiles = sizeof($_FILES['file']["name"]);
$msg = "";
for ($i = 0; $i < $numoffiles; $i++) {	
	move_uploaded_file($_FILES['file']['tmp_name'][$i], $_SERVER['DOCUMENT_ROOT']."/upload/" . $_FILES['file']['name'][$i]);
	$msg .= "Файл ".$_FILES['file']['name'][$i]." загружен<br>";
}
print $msg;
?>